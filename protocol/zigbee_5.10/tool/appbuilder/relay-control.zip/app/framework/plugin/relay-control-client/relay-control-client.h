// *******************************************************************
// * relay-control-client.h
// *
// *
// * Copyright 2012 by Ember Corporation. All rights reserved.              *80*
// *******************************************************************

// Convenience method to send a set message to the server
void emberAfPluginRelayControlClientSendSetRelayState(EmberNodeId nodeId,
                                                      uint8_t srcEndpoint,
                                                      uint8_t dstEndpoint,
                                                      bool isEnabled,
                                                      uint32_t magicNumber);
